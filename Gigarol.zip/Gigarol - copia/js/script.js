// Selección de elementos del DOM

/* const nombre = document.getElementById("nombre");
const apellido = document.getElementById("apellido");
const documento = document.getElementById("dni");
const diaNacimiento = document.getElementById("dia_nacimiento");
const mesNacimiento = document.getElementById("mes_nacimiento");
const añoNacimiento = document.getElementById("año_nacimiento");
const codigoArea = document.getElementById("codigo_area");
const numeroTelefono = document.getElementById("numero");
const calle = document.getElementById("calle");
const numeroCalle = document.getElementById("numero_calle");
const correo = document.getElementById("email");
const clave = document.getElementById("clave");
const formulario = document.getElementById("form");
const parrafo = document.getElementById("warnings");

// Función para validar el formulario al enviar
formulario.addEventListener("submit", e => {
    e.preventDefault(); // Evita que el formulario se envíe de forma predeterminada
    let warnings = "";
    let entrar = false;
    const regexEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,5})+$/;

    // Limpia los mensajes de advertencia previos
    parrafo.innerHTML = "";

    // Validación de cada campo
    if (nombre.value.length < 2) {
        warnings += "El nombre es muy corto <br>";
        entrar = true;
    }
    if (apellido.value.length < 2) {
        warnings += "El apellido es muy corto<br>";
        entrar = true;
    }
    if (documento.value.length < 6) {
        warnings += "El DNI es inválido <br>";
        entrar = true;
    }
    if (diaNacimiento.value === "") {
        warnings += "Por favor elija un día <br>";
        entrar = true;
    }
    if (mesNacimiento.value === "") {
        warnings += "Por favor elija un mes <br>";
        entrar = true;
    }
    if (añoNacimiento.value < 1930 || añoNacimiento.value > 2500) {
        warnings += "Ingrese un año válido <br>";
        entrar = true;
    }
    if (codigoArea.value < 11 || codigoArea.value > 3894) {
        warnings += "Código de área inválido <br>";
        entrar = true;
    }
    if (numeroTelefono.value.length < 6) {
        warnings += "Número telefónico inválido<br>";
        entrar = true;
    }
    if (calle.value === "") {
        warnings += "Ingrese la dirección<br>";
        entrar = true;
    }
    if (numeroCalle.value === "") {
        warnings += "Ingrese el número de la calle <br>";
        entrar = true;
    }
    if (!regexEmail.test(correo.value)) {
        warnings += "El correo no es válido <br>";
        entrar = true;
    }
    if (clave.value.length < 6) {
        warnings += "La contraseña es muy corta <br>";
        entrar = true;
    }

    // Mostrar advertencias si hay errores, de lo contrario, mostrar éxito
    if (entrar) {
        parrafo.innerHTML = warnings;
    } else {
        parrafo.innerHTML = "Formulario Enviado!";
    }
}); */

document.addEventListener("DOMContentLoaded", function() {
    const formularioContacto = document.getElementById("formulario-contacto");
  
    formularioContacto.addEventListener("submit", function(event) {
      event.preventDefault();
      let warnings = "";
      let entrar = false;
      const regexEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,5})+$/;
  
      const nombre = document.getElementById("nombre");
      const email = document.getElementById("email");
      const mensaje = document.getElementById("mensaje");
  
      // Validación del formulario de contacto
      if (nombre.value.trim() === "") {
        warnings += "Por favor, ingresa tu nombre.<br>";
        entrar = true;
      }
      if (!regexEmail.test(email.value)) {
        warnings += "Por favor, ingresa un correo electrónico válido.<br>";
        entrar = true;
      }
      if (mensaje.value.trim() === "") {
        warnings += "Por favor, ingresa un mensaje.<br>";
        entrar = true;
      }
  
      if (entrar) {
        mostrarMensaje(warnings, "error");
      } else {
        mostrarMensaje("Mensaje enviado con éxito.", "success");
      }
    });
  
    function mostrarMensaje(mensaje, tipo) {
      const mensajesDiv = document.createElement("div");
      mensajesDiv.classList.add("mensaje-" + tipo);
      mensajesDiv.innerHTML = mensaje;
      const formularioDiv = document.getElementById("formulario-contacto");
      formularioDiv.appendChild(mensajesDiv);
      setTimeout(function() {
        mensajesDiv.remove();
      }, 3000);
    }
  });
  